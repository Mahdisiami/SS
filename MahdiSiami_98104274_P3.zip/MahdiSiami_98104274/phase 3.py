import pydub
import numpy as np
import sounddevice as sd
from matplotlib import pyplot as plt
from scipy.io.wavfile import read, write
import wavio
import math
import cv2
import inline as inline
import matplotlib as matplotlib
import numpy
import matplotlib
import numpy as np
from matplotlib import pyplot as plt
from PIL import Image, ImageFilter
#%matplotlib inline
import pandas as pd

# note file to music //// given code
notes_base = 2**(np.arange(12)/12)*27.5
notes_duration = np.array([3200, 1600, 800, 400, 200, 100])*0.3
notes_ann = ['A', 'A#', 'B', 'C', 'C#', 'D', 'Eb', 'E', 'F', 'F#', 'G', 'G#']

def sin_wave(f, n, fs):
    x = np.linspace(0, 2*np.pi, n)
    ring = 30
    xp = np.linspace(0, -1*(n*ring/fs), n)
    y = np.sin(x*f*(n/fs))*np.exp(xp)
    z = np.zeros([n, 2])
    z[:, 0] = y
    z[:, 1] = y
    return z

def play_note(note_id, octave, dur, fs):
    if (note_id < 3) :
        octave += 1
    y = sin_wave(notes_base[note_id]*2**octave, int(notes_duration[dur]*(fs/1000)), fs)
    sd.play(y, fs)
    sd.wait()
    return

def put_note(note_id, octave, dur, fs):
    if (note_id < 3) :
        octave += 1
    y = sin_wave(notes_base[note_id]*2**octave, int(notes_duration[dur]*(fs/1000)), fs)
    return y

def get_music(music_notes, fs):
    m = []
    for item in music_notes:
        y = put_note(item[0], item[1], item[2], fs)
        m.append(y)
    m = np.concatenate(m, 0)
    return m
# ////////////////////// file processing functions

# finding template in given image
def templatematcher(template , threshhold , image):
    img_gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)  # convert to gray
    # applying search
    res = cv2.matchTemplate(img_gray, template, cv2.TM_CCOEFF_NORMED)
    loc = np.where(res >= threshhold)
    return loc

# making (n , 2) location file by stack and sorting by x then deleting extra copies and zeros

def deletezeros(arr):
    j = 0
    for i in range(len(arr)):
        if (arr[i] > 0):
            j = j + 1
    output = np.zeros(shape=(j))
    k = 0
    for i in range(len(arr)):
        if(arr[i] > 0):
            output[k] = arr[i]
            k = k+1
    return output

def deletexzeros(arr):
    j = 0
    for i in range(len(arr)):
        if (arr[i][0] > 0):
            j = j + 1
    output = np.zeros(shape=(j,2 ))
    k = 0
    for i in range(len(arr)):
        if(arr[i][0] > 0):
            output[k] = arr[i]
            k = k+1

    return output

def deletexzeros3(arr):
    j = 0
    for i in range(len(arr)):
        if (arr[i][0] > 0):
            j = j + 1
    output = np.zeros(shape=(j,3 ))
    k = 0
    for i in range(len(arr)):
        if(arr[i][0] > 0):
            output[k] = arr[i]
            k = k+1

    return output

def locationmaker(loc , y):
    loc = np.stack((loc[1], loc[0]), axis=1)
    # sort by x
    s = pd.DataFrame(loc, columns=['x', 'y'])
    locs = s.sort_values(by='x')
    locsnp = locs.to_numpy()
   # for i in range(len(locsnp)):
    #    print(locsnp[i])
    #print(locsnp)
    # deleting extra copies
    out1 = np.zeros(shape=(len(loc) , 2))
    out2 = np.zeros(shape=(len(loc) , 2))
    out3 = np.zeros(shape=(len(loc) , 2))
    out4 = np.zeros(shape=(len(loc) , 2))
    out5 = np.zeros(shape=(len(loc) , 2))

    j1 = 0
    j2 = 0
    j3 = 0
    j4 = 0
    j5 = 0

    for i in range(len(locsnp)):
        # first line
        if (locsnp[i][1] > y[0] - 40 and locsnp[i][1] < y[4] + 40):
            out1[j1] = locsnp[i]
            j1 = j1 + 1
    for i in range(len(locsnp)):
        # second line
        if (locsnp[i][1] > y[5] - 40 and locsnp[i][1] < y[9] + 40 and y[5] != 0):
            out2[j2] = locsnp[i]
            j2 = j2 + 1
    for i in range(len(locsnp)):
        # 3 line
        if (locsnp[i][1] > y[10] - 40 and locsnp[i][1] < y[14] + 40 and y[10] != 0):
            out3[j3] = locsnp[i]
            j3 = j3 + 1
    for i in range(len(locsnp)):
        # 4 line
        if(locsnp[i][1] > y[15]-40 and locsnp[i][1] < y[19]+40 and y[15]!=0 ):
            out4[j4] = locsnp[i]
            j4 = j4 + 1

    for i in range(len(locsnp)):
        # 5 line
        if(locsnp[i][1] > y[20]-40 and locsnp[i][1] < y[24]+40 and y[20]!=0):
            out5[j5] = locsnp[i]
            j5 = j5 + 1

    output1 = np.zeros(shape=(len(out1), 2))
    output2 = np.zeros(shape=(len(out2), 2))
    output3 = np.zeros(shape=(len(out3), 2))
    output4 = np.zeros(shape=(len(out4), 2))
    output5 = np.zeros(shape=(len(out5), 2))
    j1 = 0
    j2 = 0
    j3 = 0
    j4 = 0
    j5 = 0
    # 1
    for i in range(len(out1)):
        if (out1[i][0] > 256 and out1[i][0] < 1070):
            if (j1 == 0):
                output1[j1] = out1[i]
                j1 = j1 + 1
            elif (((out1[i][0] - out1[i - 1][0]) > 5)):
                output1[j1] = out1[i]
                j1 = j1 + 1
    #2
    for i in range(len(out2)):
        if (out2[i][0] > 135 and out2[i][0] < 1070):
            if (j2 == 0):
                output2[j2] = out2[i]
                j2 = j2 + 1
            elif (((out2[i][0] - out2[i - 1][0]) > 5)):
                output2[j2] = out2[i]
                j2 = j2 + 1

     # 3
    for i in range(len(out3)):
        if (out3[i][0] > 135 and out3[i][0] < 1070):
            if (j3 == 0):
                output3[j3] = out3[i]
                j3 = j3 + 1
            elif (((out3[i][0] - out3[i - 1][0]) > 5)):
                output3[j3] = out3[i]
                j3 = j3 + 1

    # 4
    for i in range(len(out4)):
        if (out4[i][0] > 135 and out4[i][0] < 1070):
            if (j4 == 0):
                output4[j4] = out4[i]
                j4 = j4 + 1
            elif (((out4[i][0] - out4[i - 1][0]) > 5)):
                output4[j4] = out4[i]
                j4 = j4 + 1

    # 5
    for i in range(len(out5)):
        if (out5[i][0] > 135 and out5[i][0] < 1070):
            if (j5 == 0):
                output5[j5] = out5[i]
                j5 = j5 + 1
            elif (((out5[i][0] - out5[i - 1][0]) > 5)):
                output5[j5] = out5[i]
                j5 = j5 + 1


    out = np.concatenate((output1, output2 , output3 , output4 , output5))
    return deletexzeros(out)


# y dimension of lines in an array
def lineargumentydetector(image):

    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)  # convert to gray
    edges = cv2.Canny(gray, 50, 150, apertureSize=3)  # shade the lines

    minLineLength = 500
    lines = cv2.HoughLines(edges, 1, np.pi / 180, minLineLength)
    y = np.zeros(shape=25)
    j = 0
    for line in lines:
        rho, theta = line[0]
        a = np.cos(theta)
        b = np.sin(theta)
        x0 = a * rho
        y0 = b * rho
        x1 = int(x0 + 1000 * (-b))
        y1 = int(y0 + 1000 * (a))
        x2 = int(x0 - 1000 * (-b))
        y2 = int(y0 - 1000 * (a))
        y[j] = y2
        j = j + 1
    # sort from low to high
    y = sorted(y, reverse=False)
    # deleting near line locations
    yout = np.zeros(shape=int(len(y) / 2))
    j = 0
    for i in range(len(y)):
        if (i == 0):
            yout[j] = y[i]
            j = j + 1
        elif (y[i] - y[i - 1] > 5):
            yout[j] = y[i]
            j = j + 1

    return yout
def notelistmaker(array):
    array = array.astype(int)
    list = array.tolist()
    return list

def organizer(locsnp , y):
    out1 = np.zeros(shape=(len(locsnp) , 3))
    out2 = np.zeros(shape=(len(locsnp) , 3))
    out3 = np.zeros(shape=(len(locsnp) , 3))
    out4 = np.zeros(shape=(len(locsnp) , 3))
    out5 = np.zeros(shape=(len(locsnp) , 3))

    j1 = 0
    j2 = 0
    j3 = 0
    j4 = 0
    j5 = 0

    for i in range(len(locsnp)):
        # first line
        if (locsnp[i][1] > y[0] - 40 and locsnp[i][1] < y[4] + 40):
            out1[j1] = locsnp[i]
            j1 = j1 + 1
    s = pd.DataFrame(out1, columns=['x', 'y', 'z'])
    out1 = s.sort_values(by='x')
    output1 = out1.to_numpy()
    for i in range(len(locsnp)):
        # second line
        if (locsnp[i][1] > y[5] - 40 and locsnp[i][1] < y[9] + 40 and y[5] != 0):
            out2[j2] = locsnp[i]
            j2 = j2 + 1
    s = pd.DataFrame(out2, columns=['x', 'y', 'z'])
    out2 = s.sort_values(by='x')
    output2 = out2.to_numpy()
    for i in range(len(locsnp)):
        # 3 line
        if (locsnp[i][1] > y[10] - 40 and locsnp[i][1] < y[14] + 40 and y[10] != 0):
            out3[j3] = locsnp[i]
            j3 = j3 + 1
    s = pd.DataFrame(out3, columns=['x', 'y', 'z'])
    out3 = s.sort_values(by='x')
    output3 = out3.to_numpy()
    for i in range(len(locsnp)):
        # 4 line
        if(locsnp[i][1] > y[15]-40 and locsnp[i][1] < y[19]+40 and y[15]!=0 ):
            out4[j4] = locsnp[i]
            j4 = j4 + 1
    s = pd.DataFrame(out4, columns=['x', 'y', 'z'])
    out4 = s.sort_values(by='x')
    output4 = out4.to_numpy()
    for i in range(len(locsnp)):
        # 5 line
        if(locsnp[i][1] > y[20]-40 and locsnp[i][1] < y[24]+40 and y[20]!=0):
            out5[j5] = locsnp[i]
            j5 = j5 + 1
    s = pd.DataFrame(out5, columns=['x', 'y' , 'z'])
    out5 = s.sort_values(by='x')
    output5 = out5.to_numpy()

    out = np.concatenate((output1 , output2 , output3 , output4 , output4))
    return deletexzeros3(out)

def notemaker(noteduredxsortarr , y2):
    for i in range(len(noteduredxsortarr)):
        if ((noteduredxsortarr[i][1] > y2[4] + 1)
        or((noteduredxsortarr[i][1] > y2[9] + 1) and y2[5]!=0)
        or ((noteduredxsortarr[i][1] > y2[14] + 1) and y2[10]!=0)
        or ((noteduredxsortarr[i][1] > y2[19] + 1) and y2[15]!=0)
        or ((noteduredxsortarr[i][1] > y2[24] + 1) and y2[20]!=0)):
            # C4
            noteduredxsortarr[i][0] = 3
            noteduredxsortarr[i][1] = 4

        if (((noteduredxsortarr[i][1] > y2[4] - 5) and (noteduredxsortarr[i][1] <= y2[4] + 5 - 4))
                or ((noteduredxsortarr[i][1] > y2[9] - 5)and (noteduredxsortarr[i][1] <= y2[9] + 1) and y2[5] != 0)
                or ((noteduredxsortarr[i][1] > y2[14] - 5) and noteduredxsortarr[i][1] <= y2[14] + 1 and y2[10] != 0)
                or ((noteduredxsortarr[i][1] > y2[19] - 5) and noteduredxsortarr[i][1] <= y2[19] + 1 and y2[15] != 0)
                or ((noteduredxsortarr[i][1] > y2[24] - 5) and noteduredxsortarr[i][1] <= y2[24] + 1 and y2[20] != 0)):
            # D4
            noteduredxsortarr[i][0] = 5
            noteduredxsortarr[i][1] = 4

        if (((noteduredxsortarr[i][1] > y2[3] + 1) and (noteduredxsortarr[i][1] <= y2[3] + 6))
        or ((noteduredxsortarr[i][1] > y2[8] + 1) and (noteduredxsortarr[i][1] <= y2[8] + 6) and y2[5] != 0)
        or ((noteduredxsortarr[i][1] > y2[13] + 1) and (noteduredxsortarr[i][1] <= y2[13] + 6) and y2[10] != 0)
        or ((noteduredxsortarr[i][1] > y2[18] + 1) and (noteduredxsortarr[i][1] <= y2[18] + 6) and y2[15] != 0)
        or ((noteduredxsortarr[i][1] > y2[23] + 1) and (noteduredxsortarr[i][1] <= y2[23] + 6) and y2[20] != 0)
        ):
            # E4
            noteduredxsortarr[i][0] = 7
            noteduredxsortarr[i][1] = 4

        if (((noteduredxsortarr[i][1] > y2[3] - 5) and (noteduredxsortarr[i][1] <= y2[3] + 1))
        or ((noteduredxsortarr[i][1] > y2[8] - 5) and (noteduredxsortarr[i][1] <= y2[8] + 1) and y2[5] != 0)
        or ((noteduredxsortarr[i][1] > y2[13] - 5) and (noteduredxsortarr[i][1] <= y2[13] + 1) and y2[ 10] != 0)
        or ((noteduredxsortarr[i][1] > y2[18] - 5) and (noteduredxsortarr[i][1] <= y2[18] + 1) and y2[15] != 0)
        or ((noteduredxsortarr[i][1] > y2[23] -5) and (noteduredxsortarr[i][1] <= y2[23] + 1) and y2[20] != 0)

        ):
            # F4
            noteduredxsortarr[i][0] = 8
            noteduredxsortarr[i][1] = 4

        if (((noteduredxsortarr[i][1] > y2[2] + 1) and ((noteduredxsortarr[i][1] < y2[2] + 6)))
        or ((noteduredxsortarr[i][1] > y2[7] + 1) and (noteduredxsortarr[i][1] <= y2[7] + 6) and y2[5] != 0)
        or ((noteduredxsortarr[i][1] > y2[12] + 1) and (noteduredxsortarr[i][1] <= y2[12] + 6) and y2[10] != 0)
        or ((noteduredxsortarr[i][1] > y2[17] + 1) and (noteduredxsortarr[i][1] <= y2[17] + 6) and y2[15] != 0)
        or ((noteduredxsortarr[i][1] > y2[22] + 1) and (noteduredxsortarr[i][1] <= y2[22] + 6) and y2[20] != 0)

        ):
            # G4
            noteduredxsortarr[i][0] = 10
            noteduredxsortarr[i][1] = 4

        if (((noteduredxsortarr[i][1] > y2[2] - 5) and (noteduredxsortarr[i][1] < y2[2] + 1))
        or ((noteduredxsortarr[i][1] > y2[7] - 5) and (noteduredxsortarr[i][1] <= y2[7] + 1) and y2[5] != 0)
        or ((noteduredxsortarr[i][1] > y2[12] - 5) and (noteduredxsortarr[i][1] <= y2[12] + 1) and y2[10] != 0)
        or ((noteduredxsortarr[i][1] > y2[17] - 5) and (noteduredxsortarr[i][1] <= y2[17] + 1) and y2[15] != 0)
        or ((noteduredxsortarr[i][1] > y2[22] - 5) and (noteduredxsortarr[i][1] <= y2[22] + 1) and y2[20] != 0)
        ):
            # A4
            noteduredxsortarr[i][0] = 0
            noteduredxsortarr[i][1] = 4

        if (((noteduredxsortarr[i][1] > y2[1] + 1) and (noteduredxsortarr[i][1] < y2[1] +6 ))
        or ((noteduredxsortarr[i][1] > y2[6] + 1) and (noteduredxsortarr[i][1] <= y2[6] + 6) and y2[5] != 0)
        or ((noteduredxsortarr[i][1] > y2[11] + 1) and (noteduredxsortarr[i][1] <= y2[11] + 6) and y2[10] != 0)
        or ((noteduredxsortarr[i][1] > y2[16] + 1) and (noteduredxsortarr[i][1] <= y2[16] + 6) and y2[15] != 0)
        or ((noteduredxsortarr[i][1] > y2[21] + 1) and (noteduredxsortarr[i][1] <= y2[21] + 6) and y2[20] != 0)
):
            # B4
            noteduredxsortarr[i][0] = 2
            noteduredxsortarr[i][1] = 4
        if (((noteduredxsortarr[i][1] > y2[1] - 5) and (noteduredxsortarr[i][1] < y2[1] + 1))
        or ((noteduredxsortarr[i][1] > y2[6] - 5) and (noteduredxsortarr[i][1] <= y2[6] + 1) and y2[5] != 0)
        or ((noteduredxsortarr[i][1] > y2[11] - 5) and (noteduredxsortarr[i][1] <= y2[11] + 1) and y2[10] != 0)
        or ((noteduredxsortarr[i][1] > y2[16] - 5) and (noteduredxsortarr[i][1] <= y2[16] + 1) and y2[15] != 0)
        or ((noteduredxsortarr[i][1] > y2[21] - 5) and (noteduredxsortarr[i][1] <= y2[21] + 1) and y2[20] != 0)
      ):
            # C5
            noteduredxsortarr[i][0] = 3
            noteduredxsortarr[i][1] = 5

        if (((noteduredxsortarr[i][1] > y2[0] + 1) and (noteduredxsortarr[i][1] < y2[0] +6))
        or ((noteduredxsortarr[i][1] > y2[5] + 1) and (noteduredxsortarr[i][1] <= y2[5] + 6) and y2[5] != 0)
        or ((noteduredxsortarr[i][1] > y2[10] + 1) and (noteduredxsortarr[i][1] <= y2[10] + 6) and y2[10] != 0)
        or ((noteduredxsortarr[i][1] > y2[15] + 1) and (noteduredxsortarr[i][1] <= y2[15] + 6) and y2[15] != 0)
        or ((noteduredxsortarr[i][1] > y2[20] + 1) and (noteduredxsortarr[i][1] <= y2[20] + 6) and y2[20] != 0)
):
            # D5
            noteduredxsortarr[i][0] = 5
            noteduredxsortarr[i][1] = 5

        if (((noteduredxsortarr[i][1] > y2[0] - 5) and (noteduredxsortarr[i][1] < y2[0] + 1))
                or ((noteduredxsortarr[i][1] > y2[5] - 5) and (noteduredxsortarr[i][1] <= y2[5] + 1) and y2[5] != 0)
                or ((noteduredxsortarr[i][1] > y2[10] - 5) and (noteduredxsortarr[i][1] <= y2[10] + 1) and y2[10] != 0)
                or ((noteduredxsortarr[i][1] > y2[15] - 5) and (noteduredxsortarr[i][1] <= y2[15] + 1) and y2[15] != 0)
                or ((noteduredxsortarr[i][1] > y2[20] - 5) and (noteduredxsortarr[i][1] <= y2[20] + 1) and y2[20] != 0)

        ):
            # E5
            noteduredxsortarr[i][0] = 7
            noteduredxsortarr[i][1] = 5

        if (((noteduredxsortarr[i][1] > y2[0] - 9) and (noteduredxsortarr[i][1] < y2[0] - 3))
        or ((noteduredxsortarr[i][1] > y2[5] - 9) and (noteduredxsortarr[i][1] <= y2[5] -3) and y2[5] != 0)
        or ((noteduredxsortarr[i][1] > y2[10] - 9) and (noteduredxsortarr[i][1] <= y2[10] -3) and y2[10] != 0)
        or ((noteduredxsortarr[i][1] > y2[15] - 9) and (noteduredxsortarr[i][1] <= y2[15] -3) and y2[15] != 0)
        or ((noteduredxsortarr[i][1] > y2[20] -9) and (noteduredxsortarr[i][1] <= y2[20] -3) and y2[20] != 0)
):
            # F5
            noteduredxsortarr[i][0] = 8
            noteduredxsortarr[i][1] = 5

        if((noteduredxsortarr[i][1] >= y2[0]-9)
                or ((noteduredxsortarr[i][1] <= y2[5] - 9)  and y2[5] != 0)
                or ((noteduredxsortarr[i][1] <= y2[10] - 9) and y2[10] != 0)
                or ((noteduredxsortarr[i][1] <= y2[15] - 9) and y2[15] != 0)
                or ((noteduredxsortarr[i][1] <= y2[20] - 9) and y2[20] != 0)

        ):
            #G5
             noteduredxsortarr[i][0] = 10
             noteduredxsortarr[i][1] = 5

    return noteduredxsortarr
#//////////////////////////////////////////

#img = cv2.imread("test0.png")   # reading picture
#print(lineargumentydetector(img))


noteimage = cv2.imread("test3.png")                            # reads the image

y2 = lineargumentydetector(noteimage)
y3 = deletezeros(y2)
y2 = y3
print(y3)
y4 = np.zeros(shape=(25))
for i in range(len(y3)):
    y4[i] = y3[i]

wholetemp = cv2.imread("whole.png",0)
wwh, hwh = wholetemp.shape[::-1]             # find template sizes

whitetemp = cv2.imread("white.png",0)
wwt, hwt = whitetemp.shape[::-1]             # find template sizes

blacktemp = cv2.imread("black.png",0)          # reads the template image in gray
wb, hb = blacktemp.shape[::-1]             # find template sizes


whole0 = templatematcher(wholetemp , 0.8 , noteimage )
whole = locationmaker(whole0 , y4)
wholes = np.zeros(shape=(len(whole),3))
for i in range(len(wholes)):
    wholes[i][0]= whole[i][0]
    wholes[i][1]= whole[i][1]
    wholes[i][2]= 1

white0 = templatematcher(whitetemp , 0.8 , noteimage )
white = locationmaker(white0 , y4)
whites = np.zeros(shape=(len(white),3))
for i in range(len(whites)):
    whites[i][0]= white[i][0]
    whites[i][1]= white[i][1]
    whites[i][2]= 2

black0 = templatematcher(blacktemp , 0.5 , noteimage )
black = locationmaker(black0 , y4)
blackes = np.zeros(shape=(len(black),3))
for i in range(len(blackes)):
    blackes[i][0]= black[i][0]
    blackes[i][1]= black[i][1]
    blackes[i][2]= 1
print(blackes)
print(len(blackes))
notedured = np.concatenate((wholes , whites , blackes))
#print(notedured)
'''
a = pd.DataFrame(notedured , columns=['x' , 'y' , 'duration'])
noteduredxsort = a.sort_values(by='x')
noteduredxsortarr = noteduredxsort.to_numpy()
'''
noteduredxsortarr = organizer(notedured , y4)
print(noteduredxsortarr)

noteduredxsortarr = notemaker(noteduredxsortarr , y4)

print(noteduredxsortarr)

fs1 = 44100
music = notelistmaker(noteduredxsortarr)
print(music)
y2 = get_music(music, fs1)
wavio.write("test3.wav", y2, fs1, sampwidth=3)